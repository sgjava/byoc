This is a custom mod of the RKAndroidTool 1.35 created specifically to uncomplicate the installation of Picuntu
By use of simple .cmd files in the root folder the tool can be placed into 1 of 3 possible modes.
Default mode:
This mode is preconfigured to flash the Picuntu kernel image to the Android RECOVERY partition.
This is the recommended way to flash the kernel as it leaves you with both Android and Linux available.
If you simply download and extract the archive, then run the Tool, this is the mode you will be in.

I have also included 3 command line scripts to change how the tool is configured:

REC2STOCK will preset the Tool to restore the recovery image to the stock Android recovery.
PIC2BOOT will preset the Tool to flash the Picuntu kernel to the Android BOOT partition.
PIC2REC will preset the Tool to flash the Picuntu kernel to the Android RECOVERY partition (the default)

Once you have set the appropriate mode, run RKAndroidTool.exe.

Detailed instructions on using this utility when installing Picuntu are available here:
https://www.miniand.com/wiki/Picuntu+Linux+Step+by+Step+Installation

TecKnight